package org.mariofc;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(value = {ArrayFlattenerTest.class, ArrayReversorTest.class})
public class ArrayReversorTestCases {
}
