package org.mariofc.services;

public interface ArrayFlattenerService {
    int[] flattenArray(int[][] inputArray);
}
