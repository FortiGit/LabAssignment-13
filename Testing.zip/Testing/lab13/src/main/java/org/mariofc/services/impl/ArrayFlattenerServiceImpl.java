package org.mariofc.services.impl;

import org.mariofc.ArrayFlattener;
import org.mariofc.services.ArrayFlattenerService;

public class ArrayFlattenerServiceImpl implements ArrayFlattenerService {
    @Override
    public int[] flattenArray(int[][] inputArray) {
        return ArrayFlattener.flattenArray(inputArray);
    }
}
